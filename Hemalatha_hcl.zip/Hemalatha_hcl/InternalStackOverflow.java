// File: InternalStackOverflow.java
// Compile: javac -cp "<path-to-mongo-driver-jar>/*" InternalStackOverflow.java
// Run: java -cp ".:<path-to-mongo-driver-jar>/*" InternalStackOverflow

import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import org.bson.Document;

import java.time.Instant;
import java.util.Scanner;

/**
 * Project: Internal Stack Overflow
 * Single-file Java program demonstrating:
 *  - A Stack implementation (DSA)
 *  - Logging operations and overflow events to MongoDB
 *
 * Requires mongodb-driver-sync on the classpath.
 */
public class InternalStackOverflow {

    // --- Custom exception to represent internal stack overflow ---
    public static class InternalStackOverflowException extends RuntimeException {
        public InternalStackOverflowException(String message) {
            super(message);
        }
    }

    // --- Generic Stack implementation with fixed capacity ---
    public static class Stack<T> {
        private final Object[] data;
        private int top = -1;
        private final int capacity;

        // MongoDB collection to log events
        private final MongoCollection<Document> logCollection;

        public Stack(int capacity, MongoCollection<Document> logCollection) {
            if (capacity <= 0) throw new IllegalArgumentException("Capacity must be > 0");
            this.capacity = capacity;
            this.data = new Object[capacity];
            this.logCollection = logCollection;
        }

        public synchronized void push(T value) {
            if (top + 1 >= capacity) {
                String msg = "Stack overflow: attempted push on full stack (capacity=" + capacity + ")";
                // Log overflow to MongoDB
                logOverflow(value, msg);
                throw new InternalStackOverflowException(msg);
            }
            data[++top] = value;
            logOperation("push", value, "ok");
        }

        @SuppressWarnings("unchecked")
        public synchronized T pop() {
            if (top < 0) {
                logOperation("pop", null, "underflow");
                return null;
            }
            T val = (T) data[top];
            data[top--] = null;
            logOperation("pop", val, "ok");
            return val;
        }

        @SuppressWarnings("unchecked")
        public synchronized T peek() {
            if (top < 0) return null;
            return (T) data[top];
        }

        public synchronized boolean isEmpty() { return top < 0; }

        public synchronized int size() { return top + 1; }

        public synchronized void display() {
            System.out.println("Stack (top -> bottom):");
            for (int i = top; i >= 0; i--) {
                System.out.println("  " + data[i]);
            }
            logOperation("display", null, "ok");
        }

        // --- Logging helpers ---
        private void logOperation(String op, Object value, String status) {
            try {
                Document doc = new Document()
                        .append("project", "Internal Stack Overflow")
                        .append("op", op)
                        .append("value", value == null ? null : value.toString())
                        .append("status", status)
                        .append("timestamp", Instant.now().toString());
                logCollection.insertOne(doc);
            } catch (Exception e) {
                // Logging must never break the app: print to console if DB is unreachable
                System.err.println("Failed to log operation to MongoDB: " + e.getMessage());
            }
        }

        private void logOverflow(Object attemptedValue, String message) {
            try {
                Document doc = new Document()
                        .append("project", "Internal Stack Overflow")
                        .append("event", "internal_stack_overflow")
                        .append("attempted_value", attemptedValue == null ? null : attemptedValue.toString())
                        .append("capacity", capacity)
                        .append("timestamp", Instant.now().toString())
                        .append("message", message);
                logCollection.insertOne(doc);
            } catch (Exception e) {
                System.err.println("Failed to log overflow to MongoDB: " + e.getMessage());
            }
        }
    }

    // --- Main application: console menu ---
    public static void main(String[] args) {
        // MongoDB connection string — change if needed
        final String connectionString = "mongodb://localhost:27017";
        final String dbName = "internal_stack_overflow_db";
        final String collectionName = "stack_logs";

        // Create MongoDB client (try-with-resources ensures close on exit)
        try (MongoClient mongoClient = MongoClients.create(connectionString)) {
            MongoDatabase db = mongoClient.getDatabase(dbName);
            MongoCollection<Document> logs = db.getCollection(collectionName);

            // Optionally create the collection if not exists (mongodb creates on first insert).
            // Clear the collection on start? Uncomment if you want a fresh log each run:
            // logs.drop();

            // Choose a capacity (for demo), e.g., 5
            int capacity = 5;
            Stack<String> stack = new Stack<>(capacity, logs);

            System.out.println("=== Internal Stack Overflow (Java + DSA + MongoDB) ===");
            System.out.println("MongoDB connected to: " + connectionString);
            System.out.println("Database: " + dbName + ", Collection: " + collectionName);
            System.out.println("Stack capacity: " + capacity);
            System.out.println();

            Scanner sc = new Scanner(System.in);
            boolean running = true;
            while (running) {
                System.out.println("\nMenu:");
                System.out.println(" 1) Push");
                System.out.println(" 2) Pop");
                System.out.println(" 3) Peek");
                System.out.println(" 4) Display Stack");
                System.out.println(" 5) Show last 10 logs (from MongoDB)");
                System.out.println(" 0) Exit");
                System.out.print("Choose an option: ");
                String opt = sc.nextLine().trim();
                try {
                    switch (opt) {
                        case "1":
                            System.out.print("Enter value to push: ");
                            String val = sc.nextLine();
                            try {
                                stack.push(val);
                                System.out.println("Pushed: " + val);
                            } catch (InternalStackOverflowException ex) {
                                System.err.println("ERROR: " + ex.getMessage());
                            }
                            break;
                        case "2":
                            String popped = stack.pop();
                            if (popped == null) System.out.println("Stack is empty (underflow).");
                            else System.out.println("Popped: " + popped);
                            break;
                        case "3":
                            String top = stack.peek();
                            if (top == null) System.out.println("Stack is empty.");
                            else System.out.println("Top: " + top);
                            break;
                        case "4":
                            if (stack.isEmpty()) System.out.println("Stack is empty.");
                            else stack.display();
                            break;
                        case "5":
                            System.out.println("Last 10 logs (most recent first):");
                            FindIterable<Document> docs = logs.find()
                                    .sort(new Document("_id", -1))
                                    .limit(10);
                            int i = 0;
                            for (Document d : docs) {
                                i++;
                                System.out.println(i + ") " + d.toJson());
                            }
                            if (i == 0) System.out.println("No logs found.");
                            break;
                        case "0":
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid option. Try again.");
                    }
                } catch (Exception ex) {
                    System.err.println("Unexpected error: " + ex.getMessage());
                }
            }
            sc.close();
            System.out.println("Exiting. Goodbye!");
        } catch (Exception e) {
            System.err.println("Failed to connect to MongoDB: " + e.getMessage());
            System.err.println("Make sure MongoDB is running and the driver is on the classpath.");
        }
    }
}
